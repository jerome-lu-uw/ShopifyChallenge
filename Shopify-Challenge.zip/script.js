var req = new XMLHttpRequest();
var url = "https://api.nasa.gov/planetary/apod?api_key=";
var api_key = "272exxEhSDj5MU6BlfAjDgNSqXHF5ePIl9ppa22y";

req.open("GET", url + api_key);
req.send();

req.addEventListener("load", function(){
	if(req.status == 200 && req.readyState == 4){
  	var response = JSON.parse(req.responseText);
    document.getElementById("title").textContent = response.title;
    document.getElementById("date").textContent = response.date;
    document.getElementById("pic").src = response.hdurl;
    document.getElementById("explanation").textContent = response.explanation;
  }
})

var btn = document.getElementById('btn');

function Toggle(){
if(btn.classList.contains("far"))
  {
    btn.classList.remove("far");
    btn.classList.add("fas");
  }else
  {
    btn.classList.remove("fas");
    btn.classList.add("far"); 
  }
}

var clipboard = new Clipboard('.btn-copy', {
    text: function() {
      return document.querySelector('input[type=hidden]').value;
    }
});

clipboard.on('success', function(e) {
  alert("Copied!");
  e.clearSelection();
});

$("#input-url").val(location.href);

if (navigator.vendor.indexOf("Apple")==0 && /\sSafari\//.test(navigator.userAgent)) {
   $('.btn-copy').on('click', function() {
var msg = window.prompt("Copy this link", location.href);

});
  }
